// 5.1 what shows in the console?

console.log(2 > 1);

console.log(1 === 1);

console.log(true === 1);

console.log(true + true === 2);

console.log(true + true + true === 3);

console.log(true + false === 1);
