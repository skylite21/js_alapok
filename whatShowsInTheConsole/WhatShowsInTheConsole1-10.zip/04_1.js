
// 4.1 what shows in the console?

let vehicle = 'bus';

// function expresssion
var drive = function() {
  console.log('driving a '+vehicle);
};
drive();


let food = 'pizza';
cook();

// function declaration
function cook() {
  console.log('make a '+food);
}
