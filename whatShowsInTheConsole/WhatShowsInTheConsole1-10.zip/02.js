
// 2. What shows in the console?

let x = console.log('hello');

// function expression
let y = function () {
  console.log('hello');
};

console.log(x);


let myfunc = function() {
  return;
};

console.log(myfunc);
console.log(myfunc());
