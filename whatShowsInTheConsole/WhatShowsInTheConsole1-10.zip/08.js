// what shows in the console?

let counter = 3;

while( counter > 1 ) {
  console.log(counter);
  counter--;  // counter = counter -1;
}

console.log('first loop ended');

// counter = 3;
//
// while( counter > 1 ) {
//   counter--;
//   console.log(counter);
// }
//
// console.log('second loop ended');
//
//
// counter = 0;
//
// while (counter === 0) {
//   console.log('Google is your friend');
// }
//
// console.log('third loop ended');
