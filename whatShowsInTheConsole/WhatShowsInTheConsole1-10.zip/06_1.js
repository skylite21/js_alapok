
// 6.1 what shows in the console?

let appleCount = 4;
let bananaCount = 5;

if (appleCount > bananaCount && bananaCount === 5) {
  console.log('we have more than 5 apples');
}

if(appleCount > 0 && appleCount !== bananaCount) {
  console.log('we may have more apples than bananas');
}

