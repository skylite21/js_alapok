
// 3. what shows in the console?
console.log('a'+'4');
console.log('a'+9);
console.log('5'+'5');
console.log('5'-'5');
console.log('e'-4);
