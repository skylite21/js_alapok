
// what shows in the console?

let a = 9;

if (true) {
  console.log('I am always right');
} else {
  console.log('I am always wrong');
}

let x = 95;
if(false || x === 100) {
  console.log('We arrived');
} else {
  console.log('We are not there yet');
}


if( false || x === 95 ) {
  console.log('We arrived');
} else {
  console.log('We are not there yet');
}
