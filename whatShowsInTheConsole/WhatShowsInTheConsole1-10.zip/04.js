
// 4. what shows in the console?

let f;
console.log(f);

// hoisting
console.log(v);
var v;

console.log(t);
const t = 0;

console.log(r);
let r;


