
// 1.1 What shows in the console?

let a = 9;
a = 10;
a = a + 50;

console.log(a);
console.log('a');
