// 7. what shows in the console?

let a = 9;
a = 9/'seven';
console.log(a);

if (a === NaN) {
  console.log('a is not a number');
} else {
  console.log('Meow');
}

if(isNaN(a)) {
  console.log('a is not really a number');
} else {
  console.log('Wow it\'s a birdie!');
}

