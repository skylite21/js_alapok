
// 8.1 what shows in the console?

//  nullától, addig amíg az i < 3 egyessével
// for (let i = 0; i < 3; i++) {
//   console.log(i);
// }


// for (let i = 0; i > 3; i++) {
//   console.log(i);
// }

// for (let i = 10; i >= 0; i--) {
//   console.log(i);
// }

for (let i = 0; i <= Infinity; i++) {
  console.log('hello');
}
