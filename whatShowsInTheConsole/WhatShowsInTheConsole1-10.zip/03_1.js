
// 3.1 what shows in the console?

console.log(NaN+23);
console.log(NaN+'hello');

let a = 9; 
console.log(a+'a');

let h = 'h';
console.log(h+'ello');

// let 9 = 10;
