
// 5. what shows in the console?

console.log(typeof('a'));

console.log(typeof(3));

console.log(typeof(NaN));

console.log(typeof([]));

console.log(typeof(false));

