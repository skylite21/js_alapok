
// 5.1 what shows in the console?

console.log(typeof('a'+'a'));

console.log(typeof('2'+3));

console.log(typeof(3+2));

console.log(typeof(NaN+'f'));

console.log(typeof(Infinity));

