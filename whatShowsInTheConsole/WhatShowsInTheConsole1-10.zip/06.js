
// 6. what shows in the console?

let a = 4;
let b = 9;

if (a > b) {
  console.log('Howdy');
} else {
  console.log('Hello');
}


let score = '10';

if (10 == score) {
  console.log('we have a winner!');
} else {
  console.log('we dont have a winner');
}

if (10 === score) {
  console.log('we have a winner! YAY!!');
} else {
  console.log('we dont have a winner, sorry');
}


