
// 1. What shows in the console??

let a = 9;
let b = a;
b = -4;
a = 3;
console.log(a);
console.log(b);


